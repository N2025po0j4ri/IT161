import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Nirupama Poojari
 * @version 4.22
 * @since   2021-12
 */
/**
 * Method: CVehicleFinal
 * */
public class CVehicleFinal {
	// Connection to database
	private static Connection m_conAdministrator;
	/**
	 * Method: main
	 * @param args String
	 */
	public static void main(String[] args) {
		//Assigns DisplayPickupLocations Method
		
		DisplayPickupLocations();
		
		// Declare variables for asking customer input
				//String strResponse = "";
				String strPhoneNumber = "";
				String strEmail = "";
				String strName = "";
				
				int intNumVehicles;
				int intNumDays;
				String strVehicleType = "";
				
				strName = getCustomerName();			
				// Phone number is in the correct format
				strPhoneNumber = getPhoneNumber(); 
				// Email is in the correct format
				strEmail = getUserEmail();			
				// Date is in the correct format
				String strPickupDate = getPickupDate();			
				intNumDays = getNoDaysRent();
				//Converts strResponse into integer
				intNumVehicles = Integer.parseInt(getNoVehiclesRent());
				displayInfo(strPhoneNumber, strEmail, strName, intNumVehicles, intNumDays);
				

		//int totalNumber = ReadIntegerFromUser();
	}
	/**
	 * Method: displayInfo
	 * @param strPhoneNumber String
	 * @param strEmail String
	 * @param strName String
	 * @param intNumVehicles Integer
	 * @param intNumDays Integer 
	 */
	public static void displayInfo(String strPhoneNumber, String strEmail, String strName, int intNumVehicles,
			int intNumDays) {
		String strVehicleType;
		int vehicleCount = 0;
		String VehicleType[] = new String[3];
		//Ask user for type of vehicles to rent
		do
		{
			System.out.print("Type of Vehicles to Rent: ");
			VehicleType[vehicleCount] = ReadStringFromUser();
			vehicleCount++;
		}while( vehicleCount < intNumVehicles); 
//	strVehicleType = strResponse;
		/*Prints output for Customer information details.*/
		System.out.println( "Customer Name: " + strName );
		System.out.println("Customer Phone Number: " + strPhoneNumber);
		System.out.println("Customer Email: " + strEmail);
		int i = 0;
		float fltTotalAmnt = 0;
		/*Displays information for each vehicle.*/
		while(i < intNumVehicles) {
			strVehicleType = VehicleType[i];
			System.out.println("Type of Vehicle to Rent: " + VehicleType[i]);
			if (strVehicleType.equalsIgnoreCase("Trailer")) {
				fltTotalAmnt = fltTotalAmnt + processTrailer(intNumDays, strVehicleType);
			}
			else if (strVehicleType.equalsIgnoreCase("Car")) {
				fltTotalAmnt = fltTotalAmnt +  processCar(intNumDays, strVehicleType);
			}
			else if (strVehicleType.equalsIgnoreCase("Motorbike")) {
				fltTotalAmnt = fltTotalAmnt + processMotorbike(intNumDays, strVehicleType);
			}
			
			i++;
		} 
		//Outputs the rental amount.
		System.out.printf("Rental Amount for all vehicles: $%.2f", fltTotalAmnt); 
		System.out.println();
	}
	/**
	 * Method: processMotorbike
	 * @param intNumDays Integer
	 * @param strVehicleType String
	 * @return fltTotalAmnt
	 */
	public static float processMotorbike(int intNumDays, String strVehicleType) {
		CMotorbike motorbike = new CMotorbike();
		motorbike.setFltPrice(200);
		motorbike.setStrVehicleType(strVehicleType);
		System.out.println(" How the vehicle drives: " + motorbike.getHowToDrive());
		System.out.println(" Vehicle MPG: " + motorbike.getMPG());
		float fltTotalAmnt =  intNumDays * motorbike.getFltPrice();
		System.out.printf("Total Rental for vehicle: $%.2f",intNumDays * motorbike.getFltPrice());
		System.out.println();
		return fltTotalAmnt;
	}
	/**
	 * Method: processCar
	 * @param intNumDays Integer
	 * @param strVehicleType String
	 * @return fltTotalAmnt
	 */
	public static float processCar(int intNumDays, String strVehicleType) {
		CCar car = new CCar();
		car.setFltPrice(30);
		car.setStrVehicleType(strVehicleType);
		System.out.println(" How the vehicle drives: " + car.getHowToDrive());
		System.out.println(" Vehicle MPG: " + car.getMPG());
		float fltTotalAmnt = intNumDays * car.getFltPrice();
		System.out.printf("Total Rental for vehicle: $%.2f", intNumDays * car.getFltPrice());
		System.out.println();
		return fltTotalAmnt;
	}
	/**
	 * Method: processTrailer
	 * @param intNumDays Integer
	 * @param strVehicleType String
	 * @return fltTotalAmnt
	 */
	public static float processTrailer(int intNumDays, String strVehicleType) {
		float fltTotalAmnt = 0;
		CTrailer trailer = new CTrailer();
		trailer.setFltPrice(20);
		trailer.setStrVehicleType(strVehicleType);
		System.out.println(" How the vehicle drives: " + trailer.getHowToDrive());
		System.out.println(" Vehicle MPG: " + trailer.getMPG());
		fltTotalAmnt = fltTotalAmnt + intNumDays * trailer.getFltPrice();
		System.out.printf("Total Rental for vehicle: $%.2f", intNumDays * trailer.getFltPrice());
		System.out.println();
		return fltTotalAmnt;
	}
	/**
	 * Method: getNoVehiclesRent String
	 * @return strResponse String
	 */
	public static String getNoVehiclesRent() {
		String strResponse;
		//Ask user for number of vehicles to rent
		do
		{
			System.out.print("Number of Vehicles to Rent: ");
			
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches("QUIT") )
			{
				//Assigns a method to end the program
				ProgramEnded();
				//return;
			}
		}while( IsInteger( strResponse ) == false );
		return strResponse;
	}
	/**
	 * Method: getNoDaysRent Integer
	 * @return intNumDays Integer
	 */
	public static int getNoDaysRent() {
		String strResponse;
		int intNumDays;
		// Ask user for number of days to rent
		do
		{
			System.out.print( "Number of days you are renting: " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches("QUIT") )
			{
				//Assigns a method to end the program
				ProgramEnded();
				//return;
			}
		}while( IsInteger( strResponse ) == false );
		intNumDays = Integer.parseInt(strResponse);
		return intNumDays;
	}
	/**
	 * Method: getPickupDate String
	 * @return strResponse String
	 */
	public static String getPickupDate() {
		String strResponse;
		// Ask user for pick-up date and loop until correct format is entered
		do
		{
			System.out.print( "Pick-up date in the format MM-DD-YYYY or MM/DD/YYYY: " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches("QUIT") )
			{
				//Assigns a method to end the program
				ProgramEnded();
				//return;
			}
		}while( IsValidDate( strResponse ) == false );
		return strResponse;
	}
	/**
	 * Method: getUserEmail String
	 * @return strResponse String
	 */
	public static String getUserEmail() {
		String strResponse;
		// Ask user for email and loop until correct format is entered
		do
		{
			System.out.print( "Email: " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches("QUIT") )
			{
				ProgramEnded();
				//return;
			}
		}while( IsValidEmailAddress( strResponse ) == false );
		return strResponse;
	}
	/**
	 * Method: getPhoneNumber String
	 * @return strResponse String
	 */
	public static String getPhoneNumber() {
		String strResponse;
		// Ask user for phone number and loop until correct format is entered
		do
		{
			System.out.print( "Phone number in the format '###-###-####' or '##########': " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches("QUIT") )
			{
				ProgramEnded();
				//return;
			}
		}while( IsValidPhoneNumber( strResponse ) == false );
		return strResponse;
	}
	/**
	 * Method: getCustomerName String
	 * @return strName String
	 */
	public static String getCustomerName() {
		String strName;
		// Ask user for first name
		System.out.print( "Customer Name: " );
		strName = ReadStringFromUser();
		// Check for quit
		if( strName.toUpperCase().matches( "QUIT" ) )
		{
			ProgramEnded();
			// return;
		}
		return strName;
	}
	/**
	 * Method: DisplayPickupLocations
	 * */
	public static void DisplayPickupLocations() {
		boolean connected = OpenDatabaseConnectionMSAccessJRE8();
		//System.out.println("Database connection sucessful? " +connected);
		System.out.println("OpenDatabaseConnectionMSAccess : Connection Established - awesome work!"); 

		//Declares string variable and assigns
		// sqlCommand and rsTEmployees to 'null'
		String strSelect =""; 
		Statement sqlCommand = null;
		ResultSet rsTEmployees = null; 

		strSelect = "SELECT *"
				+ " FROM TLocations"
				+ " ORDER BY intPickupID";

		try {
			sqlCommand = m_conAdministrator.createStatement();
	

			ResultSet rstTTeams = sqlCommand.executeQuery( strSelect );
			

			//ResultSet rstTEmployees;
			//ResultSet rstTEmployees;
			while ( rstTTeams.next() == true) 
			{
				// Get column data for current row 
			//	String strFirstName = rstTTeams.getString( 5 );
				String strAddress = rstTTeams.getString( 1 );
				//rstTTeams.
				// Print to console
			//	System.out.println("Table is: " + strTable + " strName: " + strFirstName);
			//	System.out.println("Table is: TEmployees Primary key: "+primaryKey+" strName: " + strFirstName);
				System.out.printf("ID: %-5s",rstTTeams.getString( 1 ));
				System.out.printf("Name: %-15s",rstTTeams.getString( 2 ));
				System.out.printf("Address: %-15s",rstTTeams.getString( 3 ));
				System.out.printf("City: %-10s",rstTTeams.getString( 4 ));
				System.out.printf("State: %-10s", rstTTeams.getString( 5 ));
				System.out.printf("Zip: %-10s", rstTTeams.getString( 6 ));
				System.out.println();
			//	System.out.println(" strName: " + strFirstName);
			}
	
			// Clean Up
			rstTTeams.close( );
			sqlCommand.close( );

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CloseDatabaseConnectionMSAccessJRE8();
		//System.out.println("Database disconnection successful");
		System.out.println("LoadListFromDatabase : RecordSet Closed and Command Closed");
		System.out.println("main: Process Complete");
	}	
	/**
	 * Method: OpenDatabaseConnectionMSAccessJRE8 boolean
	 * jar files: 
	 * dbHCM.accdb
	 * dbHCM Build for Students.sql
	 * mssql-jdbc-7.2.1.jre11.jar
	 * mssql-jdbc-7.2.1.jre8.jar
	 * sqljdbc4.jar
	 * @return b1nResult
	 */
	public static boolean OpenDatabaseConnectionMSAccessJRE8()
	{
		boolean b1nResult = false;

		try{
			String strConnectionString = "";

			//Server name/port, IP address/port or path for file based DB like MS Access
			// System.getProperty("user.dir") => Current working directory from where
			// application was started 
			//	strConnectionString = "jdbc:ucanacess://" + System.getProperty("user.dir")
			//			    + "\\Database\\dbHCM.accdb";

			//strConnectionString = "jdbc:ucanacess://" + "C:\\Users\\ypooj\\OneDrive\\Documents\\Database3.accdb";
			
			strConnectionString = "jdbc:ucanaccess://C://Users//ypooj//eclipse-workspace//VehicleRentalTest3NP//Database//dbVehicleRental.accdb";
			//Open a connection to the database
			m_conAdministrator = DriverManager.getConnection( strConnectionString );
			// Success 
			b1nResult = true;

		} 
		catch ( Exception e) { 
			System.out.println( "Try again - error in OpenDB ");
			System.out.println( "Error is" + e );
		} 
		return b1nResult; 
	}
	/**
	 * Method: CloseDatabaseConnectionMSAccessJRE8
	 */
	public static void CloseDatabaseConnectionMSAccessJRE8(){
		// Is there a connection object?
		if( m_conAdministrator != null )
		{
			// Yes, close the connection if not closed already
			try {
				if( m_conAdministrator.isClosed( ) == false ) 
				{
					m_conAdministrator.close( );
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * Method: ReadIntegerFromUser
	 * @return intValue
	 * */
	public static int ReadIntegerFromUser( )
	{

		int intValue = 0;

		try
		{
			String strBuffer = "";	

			// Input stream
			BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

			// Read a line from the user
			strBuffer = burInput.readLine( );

			// Convert from string to integer
			intValue = (int) Float.parseFloat( strBuffer );
		}
		catch( Exception excError )
		{
			System.out.println( excError.toString( ) );
		}


		// Return integer value
		return intValue;
	}
	
	/**
	 * Method: ReadStringFromUser - Get input from user
	 * @return strBuffer
	 */
	public static String ReadStringFromUser( )
	{

		String strBuffer = "";

		try
		{
			// Input stream
			BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

			// Read a line from the user
			strBuffer = burInput.readLine( );
		}
		catch( Exception excError )
		{
			System.out.println( excError.toString( ) );
		}

		// Return string
		return strBuffer;
	}
	
	
	/**
	 * Method: ProgramEnded - When user enters "QUIT"
	 */
	private static void ProgramEnded() {
		//Prints message in ProgramEnded
		System.out.println( "-----------------------------------------------" );
		System.out.println( "Program ended by user." );
		System.out.println( "Thank you for using CState's Vehicle Rental!" );
		System.out.println( "Please come again." );
	}
	
	
	/**
	 * Method: IsValidPhoneNumber - Check if phone number entered is in correct format
	 * @param strPhoneNumber
	 * Phone number entered by user
	 * @return blnIsValidPhoneNumber
	 */
	public static boolean IsValidPhoneNumber(String strPhoneNumber) {
		boolean blnIsValidPhoneNumber = false;
		
		try
		{
			// Declare variables
			String strStart = "^";
			String strStop = "$";
			String strDash = "\\-";
			String strPattern1 = "";
			String strPattern2 = "";
			
			// String patterns
			// ###-###-####
			strPattern1 = strStart + "\\d{3}" + strDash + "\\d{3}" + strDash + "\\d{4}" + strStop;
			// ##########
			strPattern2 = strStart + "\\d{10}" + strStop;
			
			// Does it match any of the formats?
			if( strPhoneNumber.matches( strPattern1 ) == true || 
				strPhoneNumber.matches( strPattern2 ) == true )
			{
				// Yes
				blnIsValidPhoneNumber = true;
			}
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		// Return result
		return blnIsValidPhoneNumber;
	}
	
	
	/**
	 * Method: IsValidEmailAddress Boolean
	 * @param strResponse
	 * Email entered by user
	 * @return blnIsValidEmailAddress
	 */
	private static boolean IsValidEmailAddress(String strEmailAddress) {
		boolean blnIsValidEmailAddress = false;
		
		try
		{
			// Declare variables
			String strStart = "^";
			String strStop = "$";
			String strPattern = "";
			
			// Set string pattern
			strPattern = strStart + "[a-zA-Z][a-zA-Z0-9\\.\\-]*" + "@" + "[a-zA-Z][a-zA-Z0-9\\.\\-]*\\.[a-zA-Z]{2,6}" + strStop;
			
			// Does it match?
			if( strEmailAddress.matches( strPattern ) == true )
			{
				// Yes
				blnIsValidEmailAddress = true;
			}
			
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		
		return blnIsValidEmailAddress;
	}
	
	
	/**
	 * Method: IsValidDate Boolean
	 * @param strResponse
	 * Date entered by user
	 * @return blnIsValidDate
	 */
	private static boolean IsValidDate(String strDate) {
		boolean blnIsValidDate = false;
		
		try
		{
			// Declare variables
			String strStart = "^";
			String strStop = "$";
			String strDash = "\\-";
			String strSlash = "\\/";
			String strPattern1 = "";
			String strPattern2 = "";
			
			// Set string pattern
			// MM-DD-YYYY
			strPattern1 = strStart + "\\d{2}" + strDash + "\\d{2}" + strDash + "\\d{4}" + strStop;
			// MM/DD/YYYY
			strPattern2 = strStart + "\\d{2}" + strSlash + "\\d{2}" + strSlash + "\\d{4}" + strStop;
			
			// Does it match?
			if( strDate.matches( strPattern1 ) == true ||
				strDate.matches( strPattern2 ) == true)
			{
				// Yes
				blnIsValidDate = true;
			}
			
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		
		return blnIsValidDate;
	}
	
	
	
	/**
	 * Method: IsInteger- checks if string is an integer
	 * @param strResponse
	 * String to check
	 * @return blnNumeric
	 */
	public static boolean IsInteger(String strResponse) {
		boolean blnNumeric = true;
		
		try
		{
			Integer.parseInt(strResponse);
		}
		catch( NumberFormatException e )
		{
			blnNumeric = false;
		}
		
		return blnNumeric;
	}
}
