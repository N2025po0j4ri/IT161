/**
 * @author Nirupama Poojari
 * @version 4.22
 * @since   2021-12
 **/
/**
 * Method: CCar child class
 * */
/**
 * Method: Vehicle parent class
 * */
public class CCar extends Vehicle {
	/**
	 * Method: getHowToDrive String
	 * @return String
	 * **/
	public String getHowToDrive() {
		return "steering wheel";
	}
}
