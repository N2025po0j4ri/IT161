/**
 * @author Nirupama Poojari
 * @version 4.22
 * @since   2021-12
 **/
/**
 * Method: CTrailer child class
 * */
/**
 * Method: Vehicle parent class
 * */
public class CTrailer extends Vehicle {

	/**
	 * Method: Main
	 * @param args String
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * Method: getHowToDrive String
	 * @return String
	 */
	public  String getHowToDrive() {
		return "use another vehicle to pull";
	}
	/**
	 * Method: getMPG String
	 * @return String
	 */
	public  String getMPG(){
		return "zero MPG";
	}
}
