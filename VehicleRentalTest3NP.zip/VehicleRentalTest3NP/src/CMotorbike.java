/**
 * @author Nirupama Poojari
 * @version 4.22
 * @since   2021-12
 **/
/**
 * Method: CMotorbike child class
 * */
/**
 * Method: Vehicle parent class
 * */
public class CMotorbike extends Vehicle {

	/**
	 * Method: main
	 * @param args String
	 * */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Method: getHowToDrive String
	 * */
	public  String getHowToDrive() {
		return "handle bars";
	}
}
