
/**
 * @author Nirupama Poojari
 * @version 4.22
 * @since   2021-12
 **/
/**
 * Method: Vehicle
 * */
public class Vehicle {
	int intWheels;
	int intNumOfMPG;
	String strVehicleType;
	/**
	 * Method: getFltPrice float
	 * @return the fltPrice
	 */
	public float getFltPrice() {
		return fltPrice;
	}
	/**
	 * Method: setFltPrice
	 * @param fltPrice the fltPrice to set
	 */
	public void setFltPrice(float fltPrice) {
		this.fltPrice = fltPrice;
	}
	float fltPrice;
	/**
	 * Method: getStrVehicleType String
	 * @return the strVehicleType
	 */
	public String getStrVehicleType() {
		return strVehicleType;
	}
	/**
	 * Method: setStrVehicleType
	 * @param strVehicleType the strVehicleType to set
	 */
	public void setStrVehicleType(String strVehicleType) {
		this.strVehicleType = strVehicleType;
	}
	/**
	 * *Method: main
	 * @param args String
	 **/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * Method: getHowToDrive String
	 * @return String
	 * */
	public String getHowToDrive() {
		return "";
	}
	/**
	 * Method: getMPG String
	 * @return String
	 * */
	public String getMPG(){
		return "";
	}
	/**
	 * Method: getWheels String
	 * @return String
	 * */
    public String getWheels() {
    	return "";
    }

}
